import { useState, useEffect } from "react";
import axios from "axios";
import { useLocation, useNavigate } from "react-router-dom";
import {auth} from "./firebase"

function ViewItem() {
  const [item, setItem] = useState(null);
  const loc = useLocation();
  const navigate = useNavigate();
  const user = auth.currentUser;
  

  useEffect(() => {
    if (!loc.state || !loc.state.id) {
      alert("No item selected!");
      navigate("/"); // fallback to home
      return;
    }

    const id = loc.state.id;
    const url = `http://localhost:5000/api/items/${id}`;
    axios
      .get(url)
      .then((res) => setItem(res.data))
      .catch((err) => {
        alert("Couldn't load item");
        console.error(err);
      });
  }, [loc, navigate]);

    const handleDelete = () => {
  if (window.confirm("Are you sure you want to delete this item?")) {
    axios
      .delete(`http://localhost:5000/api/items/${item._id}`)
      .then(() => {
        alert("Deleted successfully");
        navigate("/"); // back to home
      })
      .catch((err) => alert("Error deleting item"));
  }
};

  





  if (!item) return <div>Loading...</div>;

  return (
    <div className="item-card" style={{ maxWidth: 400, margin: "40px auto", padding: 20, border: "1px solid #ddd", borderRadius: 10 }}>
      <img
        src={`http://localhost:5000${item.imageUrl}`}
        alt={item.title}
        style={{ width: "100%", borderRadius: 8, marginBottom: 15 }}
      />
      <h2 style={{ marginBottom: 10 }}>{item.title}</h2>
      <p style={{ marginBottom: 10 }}>{item.description}</p>
      <p style={{ fontWeight: "bold", color: "#1b5e20" }}>₹{item.price} / hour</p>
      <button onClick={() => navigate("/home")} style={{ marginTop: 20 }}>
  ⬅ Back to Listings
</button>
{user && user.email === item.userEmail && (
  <div>
    <button onClick={handleDelete}>Delete</button>
    {user && user.email === item.userEmail && (
      <div>
        <button onClick={handleDelete}>Delete</button>
        <button
          onClick={() =>
            navigate("/post", { state: { isEditing: true, item } })
          }
        >
          Edit
        </button></div>)}
  </div>
)}

    </div>
  );
}

export default ViewItem;
