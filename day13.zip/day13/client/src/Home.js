import { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import NavBar from "./NavBar";


function Home() {
  const [items, setItems] = useState([]);
  const nav = useNavigate();

  useEffect(() => {
    let url = "http://localhost:5000/api/items";
    axios
      .get(url)
      .then((res) => {
        setItems(res.data);
      })
      .catch((err) => {
        console.log("issue " + err);
      });
  }, []);

  const viewItem =(id)=>{
    nav("/viewitem",{state:{id:id}})
  }

  return (
    <>
    <NavBar/>
      <h1>Rent My Stuff!</h1>
      <div className="items-container">
        {items.map((item) => (
          <div className="item-card" key={item._id}>
            <img src={`http://localhost:5000${item.imageUrl}`} alt={item.title} />
            <h3>{item.title}</h3>
            <p>{item.description}</p>
            <p className="price">₹{item.price} / hour</p>
            <button onClick={()=>{viewItem(item._id)}}>View</button>
          </div>
        ))}
      </div>
    </>
  );
}

export default Home;
