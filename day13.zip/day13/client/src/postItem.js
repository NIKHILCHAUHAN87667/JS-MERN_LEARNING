import { useState } from "react";
import axios from "axios";
import NavBar from "./NavBar";
import { auth } from "./firebase";
import { useLocation, useNavigate } from "react-router-dom"; 


function PostItem() {
  const [title, setTitle] = useState("");
  const [desc, setDesc] = useState("");
  const [price, setPrice] = useState("");
  const [image, setImage] = useState(null); 

 
  const hTitle = (e) => setTitle(e.target.value);
  const hDesc = (e) => setDesc(e.target.value);
  const hPrice = (e) => setPrice(e.target.value);

  const hImage = (e) => {
    const selectedFile = e.target.files[0];
    if (!selectedFile) return;

    const maxSize = 1 * 1024 * 1024 / 2; 

    if (!selectedFile.type.startsWith("image/")) {
      alert("Only image files are allowed!");
      e.target.value = "";
      return;
    }

    if (selectedFile.size > maxSize) {
      alert("File too large! Max size is 500KB.");
      e.target.value = "";
      return;
    }

    setImage(selectedFile);
  };

  const post = (e) => {
    e.preventDefault();
    const user = auth.currentUser;
  if (!user) {
    alert("You must be logged in to post!");
    return;}

    if (!title || !desc || !price || !image) {
      alert("Please fill all fields.");
      return;
    }

    const fdata = new FormData();
    fdata.append("title", title);
    fdata.append("description", desc);
    fdata.append("price", price);
    fdata.append("image", image);

    const url = "http://localhost:5000/api/items";

    axios
      .post(url, fdata, {
        headers: { "Content-Type": "multipart/form-data" },
      })
      .then((res) => {
        alert("Item posted successfully!");
        window.location.reload();
      })
      .catch((err) => {
        console.error("Upload error:", err);
        alert("Something went wrong.");
      });
  };

   return (
    <><NavBar /><div className="post-item-container">
           <h1>Post Your Item to Rent</h1>
           <form onSubmit={post} encType="multipart/form-data">
               <input type="text" placeholder="Title" value={title} onChange={hTitle} />
               <br /><br />
               <input type="text" placeholder="Description" value={desc} onChange={hDesc} />
               <br /><br />
               <input type="number" placeholder="Price (₹ per hour)" value={price} onChange={hPrice} />
               <br /><br />
               <input type="file" accept="image/*" onChange={hImage} />
               <br /><br />
               <input type="submit" value="Post" />
           </form>
       </div></>
  );

}

export default PostItem;
