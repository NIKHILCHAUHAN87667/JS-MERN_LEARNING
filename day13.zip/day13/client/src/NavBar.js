import {Link} from "react-router-dom";

function NavBar()
{
    return(
    <nav className="navbar">
    <Link to="/home">Home</Link>
    <Link to="/post">Post Items</Link>
    </nav>);
}
export default NavBar;