import { useState } from "react";
import { auth } from "./firebase";
import { createUserWithEmailAndPassword, signInWithEmailAndPassword } from "firebase/auth";
import { useNavigate } from "react-router-dom";

function Login() {
  const [email, setEmail] = useState('');
  const [pass, setPass] = useState('');
  const [isLogin, setIsLogin] = useState(true); // toggle between login/signup
  const nav = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      if (isLogin) {
        await signInWithEmailAndPassword(auth, email, pass);
        alert("Logged in successfully!");
        nav("/home")

        
      } else {
        await createUserWithEmailAndPassword(auth, email, pass);
        alert("Account created!");
      }
    } catch (err) {
      alert(err.message);
    }
  };

   return (
    <>
    <h1>Rent My Stuff</h1>
    <div className="login-container">
      <h2>{isLogin ? "Login" : "Sign Up"}</h2>
      <form onSubmit={handleSubmit}>
        <input type="email" placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} required /><br />
        <input type="password" placeholder="Password" value={pass} onChange={e => setPass(e.target.value)} required /><br />
        <button type="submit">{isLogin ? "Login" : "Sign Up"}</button>
      </form>
      <button onClick={() => setIsLogin(!isLogin)}>
        {isLogin ? "New here? Create account" : "Already have an account? Login"}
      </button>
    </div>
    </>
  );
}

export default Login;
