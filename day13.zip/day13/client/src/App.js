import { BrowserRouter , Routes , Route } from 'react-router-dom';
import './App.css';
import Home from './Home';
import PostItem from './postItem';
import NavBar from './NavBar';
import ViewItem from './ViewItem';
import Login from './Login';

function App() {
  return (
    <BrowserRouter>

      <Routes>
        <Route path='/' element={<Login/>}/>
        <Route path='/home' element={<Home/>}/>
        <Route path='/post' element={<PostItem/>}/>
        <Route path='/viewitem' element={<ViewItem/>}/>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
