// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAzh4a8lUuCxLsdoQt4aCAaHcjol0gKKaY",
  authDomain: "rentmystuff24june25.firebaseapp.com",
  projectId: "rentmystuff24june25",
  storageBucket: "rentmystuff24june25.firebasestorage.app",
  messagingSenderId: "832580455811",
  appId: "1:832580455811:web:a0605062efb8783669bab6"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);