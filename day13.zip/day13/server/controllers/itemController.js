const Item = require('../models/Item');

const createItem = async (req, res) => {
  try {
    const { title, description, price } = req.body;
   

    const imageUrl = req.file ? `/uploads/${req.file.filename}` : '';

    const item = new Item({ title, description, price, imageUrl });
    await item.save();
    res.status(201).json(item);
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
};

const getItems = async (req, res) => {
  const items = await Item.find().sort({ createdAt: -1 });
  res.json(items);
};

const getItem = async (req, res) => {
  const item = await Item.findById(req.params.id);
  if (item) res.json(item);
  else res.status(404).json({ message: 'Item not found' });
};


module.exports = { createItem, getItems, getItem };
