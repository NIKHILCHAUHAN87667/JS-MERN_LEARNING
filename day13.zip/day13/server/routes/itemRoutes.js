const express = require('express');
const multer = require('multer');
const { createItem, getItems, getItem } = require('../controllers/itemController');

const router = express.Router();

// Multer setup
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, 'uploads/'),
  filename: (req, file, cb) => cb(null, `${Date.now()}-${file.originalname}`),
});
const upload = multer({ storage });

router.post('/', upload.single('image'), createItem);
router.get('/', getItems);
router.get('/:id', getItem);
router.delete("/items/:id", async (req, res) => {
  try {
    const item = await Item.findById(req.params.id);
    if (!item) return res.status(404).send("Item not found");

    // Optional: check ownership using userEmail
    await item.deleteOne();
    res.send({ message: "Item deleted" });
  } catch (err) {
    res.status(500).send("Server error");
  }
});
router.put("/items/:id", async (req, res) => {
  try {
    const { title, description, price } = req.body;
    const item = await Item.findByIdAndUpdate(
      req.params.id,
      { title, description, price },
      { new: true }
    );
    res.send(item);
  } catch (err) {
    res.status(500).send("Server error");
  }
});


module.exports = router;
