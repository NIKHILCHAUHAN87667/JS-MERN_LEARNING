import { useState } from "react";
import axios from "axios";
import ReactMarkdown from "react-markdown";

function UploadForm() {
  const [file, setFile] = useState(null);
  const [summary, setSummary] = useState("");
  const [loading, setLoading] = useState(false);
  const [copied,setCopied] = useState(false);

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };

  const handleUpload = async (e) => {
    e.preventDefault();

    if (!file) {
      alert("Please choose a PDF to upload.");
      return;
    }

    try {
      setLoading(true);
      setSummary("");

      // Step 1: Upload file
      const formData = new FormData();
      formData.append("file", file);
      

      const uploadRes = await axios.post("http://localhost:5000/upload", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });

      const filename = uploadRes.data.ops[0].file;

     
      const summarizeRes = await axios.post("http://localhost:5000/summarize", {
        filename,
      });

      setSummary(summarizeRes.data.summary);
    } catch (err) {
      console.error(err);
      alert("Something went wrong.");
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = async () => {
    if (summary) {
      try {
        await navigator.clipboard.writeText(summary);
        setCopied(true);
        setTimeout(() => setCopied(false), 1500);
      } catch (err) {
        alert("Failed to copy summary.");
      }
    }
  };

  return (
    <div className="upload-container">
      <h2>📄 Upload a PDF to Summarize</h2>
      <form onSubmit={handleUpload}>
        <input type="file" accept="application/pdf" onChange={handleFileChange} />
        <button type="submit" disabled={loading}>
          {loading ? "Processing..." : "Upload & Summarize"}
        </button>
      </form>

      {summary && (
        <div className="summary-section">
          <h3>📝 Summary:</h3>
          <ReactMarkdown>{summary}</ReactMarkdown>
          <button
            className="copy-btn"
            onClick={handleCopy}
            type="button"
            style={{ marginTop: "12px", padding:"12px 32px" }}
          >
            {copied ? "Copied!" : "Copy"}
          </button>
        </div>
      )}
    </div>
  );
}

export default UploadForm;
