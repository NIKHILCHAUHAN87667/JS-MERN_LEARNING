import UploadForm from './UploadForm';
import './App.css';

function App() {
  return (
    <UploadForm/>
  );
}

export default App;
