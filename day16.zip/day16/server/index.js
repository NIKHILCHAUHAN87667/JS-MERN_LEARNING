const express = require("express");
const cors = require("cors");
const multer = require("multer");
const {MongoClient , ObjectId} =require("mongodb")
require("dotenv").config();
const fs = require("fs");
const pdfParse = require("pdf-parse");

const { GoogleGenerativeAI } = require("@google/generative-ai");

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

const app = express();

app.use(cors());

app.use(express.json());

app.use("/uploads", express.static("uploads"));

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, "uploads/");
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + "-" + file.originalname);
    },
});
const upload = multer({ storage });

const con = new MongoClient(process.env.MONGO_URL);
const db = con.db("PDFSummarizer");



async function extractPdfText(filePath) {
  const buffer = fs.readFileSync(filePath);
  const data = await pdfParse(buffer);
  return data.text;
}




app.post("/summarize", async (req, res) => {
  try {
    const { filename } = req.body;
    const filePath = `uploads/${filename}`;
    const text = await extractPdfText(filePath);

    const prompt = `Summarize the following document in clear bullet points:\n\n${text}`;

    const model = genAI.getGenerativeModel({ model: "gemini-2.0-flash" });
    const result = await model.generateContent(prompt);
    const summary = result.response.candidates[0].content.parts[0].text;

    res.send({ summary });
  } catch (err) {
    console.error(err);
    res.status(500).send("Something went wrong during summarization.");
  }
});




app.post("/upload",upload.single("file"),(req,res)=>{
    const coll = db.collection("pdf");
    const doc = {"file":req.file.filename}
    coll.insertOne(doc)
    .then(response=>{
        res.status(200).send({ops:[doc]});
    })
    .catch(err=>{
        res.status(500).send(err);
    })
})

app.listen(5000,()=>{console.log("server ready at 5000")})