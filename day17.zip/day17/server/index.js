const express = require('express');
const mongoose = require('mongoose');
const nodemailer = require('nodemailer');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(bodyParser.json());

mongoose.connect('mongodb://localhost:27017/otpApp', { useNewUrlParser: true, useUnifiedTopology: true });

// Mongoose Schema
const OTPSchema = new mongoose.Schema({
  email: String,
  otp: String,
  expiresAt: Date,
});
const OTP = mongoose.model('OTP', OTPSchema);

// Nodemailer transporter
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'devstatic014@gmail.com',
    pass: 'ahbqosvnfrutjeum',
  },
});

// Generate and send OTP
app.post('/send-otp', async (req, res) => {
  const { email } = req.body;
  const otp = Math.floor(100000 + Math.random() * 900000).toString();
  const expiresAt = new Date(Date.now() + 5 * 60 * 1000); // 5 mins

  await OTP.findOneAndUpdate(
    { email },
    { otp, expiresAt },
    { upsert: true, new: true }
  );

  await transporter.sendMail({
    from: 'devstatic014@gmail.com',
    to: email,
    subject: 'Your OTP Code',
    text: `Your OTP is ${otp}`,
  });

  res.json({ message: 'OTP sent' });
});

// Verify OTP
app.post('/verify-otp', async (req, res) => {
  const { email, otp } = req.body;
  const record = await OTP.findOne({ email });

  if (!record || record.otp !== otp || record.expiresAt < new Date()) {
    return res.status(400).json({ message: 'Invalid or expired OTP' });
  }

  await OTP.deleteOne({ email }); // Clean up after verification
  res.json({ message: 'OTP verified' });
});

app.listen(5000, () => console.log('Server running on port 5000'));
