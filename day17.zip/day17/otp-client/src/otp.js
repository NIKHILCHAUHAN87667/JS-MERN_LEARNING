import React, { useState } from 'react';
import axios from 'axios';


function Otp() {
  const [email, setEmail] = useState('');
  const [otp, setOTP] = useState('');
  const [step, setStep] = useState(1);
  const [message, setMessage] = useState('');
  const [resendCooldown, setResendCooldown] = useState(0);

  React.useEffect(() => {
    if (resendCooldown > 0) {
      const timer = setTimeout(() => setResendCooldown(resendCooldown - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [resendCooldown]);

  const sendOTP = async () => {
    try {
      await axios.post('http://localhost:5000/send-otp', { email });
      setStep(2);
      setMessage('OTP sent to your email');
      setResendCooldown(30);
    } catch (err) {
      setMessage('Error sending OTP');
    }
  };

  const verifyOTP = async () => {
    try {
      const res = await axios.post('http://localhost:5000/verify-otp', { email, otp });
      setMessage(res.data.message);
    } catch (err) {
      setMessage('Invalid or expired OTP');
    }
  };

  const handleResend = () => {
    if (resendCooldown === 0) sendOTP();
  };

  return (
    <div className="otp-container">
      {step === 1 ? (
        <>
          <h2 className="otp-title">Enter Your Email</h2>
          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={e => setEmail(e.target.value)}
            className="otp-input"
          />
          <button className="otp-button" onClick={sendOTP}>Send OTP</button>
        </>
      ) : (
        <>
          <h2 className="otp-title">Verify OTP</h2>
          <p className="otp-sent-to">Sent to: <strong>{email}</strong></p>
          <input
            type="text"
            placeholder="Enter OTP"
            value={otp}
            onChange={e => setOTP(e.target.value)}
            className="otp-input"
          />
          <button className="otp-button" onClick={verifyOTP}>Verify</button>
          <button
            className="otp-button"
            style={{ marginTop: 10 }}
            onClick={handleResend}
            disabled={resendCooldown > 0}
          >
            {resendCooldown > 0 ? `Resend in ${resendCooldown}s` : 'Resend OTP'}
          </button>
        </>
      )}

      {message && <p className="otp-message">{message}</p>}
    </div>
  );
}

export default Otp;