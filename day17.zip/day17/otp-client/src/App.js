
import './App.css';
import Otp from './otp';

function App() {
  return (
   <Otp/>
  );
}

export default App;
