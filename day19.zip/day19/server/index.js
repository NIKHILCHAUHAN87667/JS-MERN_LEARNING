const express = require("express");
const cors = require("cors");
const {MongoClient} = require("mongodb");
const nodemailer = require("nodemailer");
require("dotenv").config();

const app = express();
app.use(cors());
app.use(express.json());


app.post("/save",(req,res)=>{
    const con =new MongoClient(process.env.MONGO_URI);
    const db = con.db("watchdb");
    const coll = db.collection("enquiry");
    const doc = {
        "name":req.body.name,
        "email":req.body.email,
        "message":req.body.message
        
    }
    coll.insertOne(doc)
    .then(response=>{
        res.status(200).send(response)
    })
    .catch(err=>{
        res.status(500).send(err);
    })

    let transporter = nodemailer.createTransport({
        service:'gmail',
        auth:{
            user:process.env.EMAIL_USER,
            pass:process.env.EMAIL_PASS,
        }
    })

    let mailOptions = {
        from :"devstatic014@gmail.com",  
        to:"nikhilchauhan87667@gmail.com",
        subject:"Enquiry from"+req.body.name,
        text:"email"+req.body.email + "message or preffered model = "+req.body.message
    }

    transporter.sendMail(mailOptions,(error,info)=>{
        if(error){
            console.log(error);
            return res.status(500).json(error)
        }
        return res.status(200).json("mail sent");
        

    })
   






})

app.listen(9000,()=>{console.log("ready at 9000")})

