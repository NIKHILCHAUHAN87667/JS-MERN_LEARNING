import axios from "axios";
import {useState , useRef} from "react"

export default function ContactForm() {

    const [name , setName] = useState('');
    const [email, setEmail] = useState('');
    const [message , setMessage] = useState('');





  return (
    <div style={{ maxWidth: '600px', margin: '0 auto' }}>
      <h2 style={{ fontSize: '2rem', marginBottom: '1rem' }}>Buy the Chronos Watch</h2>
      <p style={{ marginBottom: '2rem' }}>
        Fill out the form and we'll reach out to complete your purchase.
      </p>

      <form
        style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}
        onSubmit={(e) => {
          e.preventDefault()
          let url = "http://localhost:9000/save";
          let data ={name , email , message}
          axios.post(url,data)
          .then(res=>{
            alert("Your Message sent we will contact you soon")
            window.location.reload();
          })
          .catch(err=>{
            console.log(err)
          })
        }}
      >
        <input
          type="text"
          placeholder="Your Name"
          required
          style={{ padding: '1rem', borderRadius: '6px', border: 'none' }}
          onChange={(e)=>{setName(e.target.value)}}
        />
        <input
          type="email"
          placeholder="Your Email"
          required
          style={{ padding: '1rem', borderRadius: '6px', border: 'none' }}
           onChange={(e)=>{setEmail(e.target.value)}}
        />
        <textarea
          placeholder="Message or preferred model"
          rows={4}
          style={{ padding: '1rem', borderRadius: '6px', border: 'none' }}
           onChange={(e)=>{setMessage(e.target.value)}}
        />

        <button
          type="submit"
          style={{
            padding: '1rem',
            background: '#00ffff',
            border: 'none',
            borderRadius: '6px',
            fontWeight: 'bold',
            cursor: 'pointer',
            color: '#000'
          }}
        >
          Submit Order Request
        </button>
      </form>
    </div>
  )
}
