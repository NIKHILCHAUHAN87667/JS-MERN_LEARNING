import { Canvas, useFrame } from '@react-three/fiber'
import { OrbitControls, useGLTF, Environment } from '@react-three/drei'
import { useRef } from 'react'

function WatchModel() {
  const ref = useRef()
  const { scene } = useGLTF('/wrist_watch.glb')

  useFrame(() => {
    ref.current.rotation.y += 0.003
  })

  return <primitive ref={ref} object={scene} scale={0.4} position={[0, -1, 0]} />
}

export default function WatchScene() {
  return (
    <Canvas camera={{ position: [0, 0, 5] }}>
      <ambientLight intensity={0.6} />
      <directionalLight position={[5, 5, 5]} />
      <Environment preset="studio" />
      <WatchModel />
      <OrbitControls enableZoom={false} autoRotate />
    </Canvas>
  )
}
