export default function HeroOverlay({ onShopNowClick }) {
  return (
    <div style={{
      position: 'absolute',
      top: '30%',
      left: '10%',
      color: 'white',
      zIndex: 10,
      maxWidth: '500px'
    }}>
      <h1 style={{ fontSize: '3rem', marginBottom: '1rem' }}>
        Timeless Precision 
      </h1>
      <p style={{ fontSize: '1.1rem', marginBottom: '1.5rem' }}>
        Discover the elegance of 3D craftsmanship with our new Chronos series.
      </p>
      <button
        onClick={onShopNowClick}
        style={{
          padding: '12px 24px',
          background: '#00ffff',
          border: 'none',
          borderRadius: '6px',
          fontWeight: 'bold',
          cursor: 'pointer'
        }}
      >
        Shop Now
      </button>
    </div>
  )
}
