import WatchScene from './Hero3D'
import HeroOverlay from './OverlayText'
import ContactForm from './ContactForm'
import {useRef} from "react";
function App() {

  const contactRef = useRef()

  const scrollToForm = () => {
    contactRef.current?.scrollIntoView({ behavior: 'smooth' })
  }
  return (
    <div style={{ width: '100vw', overflowX: 'hidden', backgroundColor: 'black' }}>
      <div style={{height:"100vh",width:"100vw", position:"relative"}}>
      <WatchScene />
      <HeroOverlay onShopNowClick={scrollToForm}/>
      </div>
      

     
     <section style={{ minHeight: '100vh', background: '#111', color: 'white', padding: '4rem 2rem' }}>
  <div style={{ maxWidth: '800px', margin: '0 auto' }}>
    <h2 style={{ fontSize: '2.5rem', marginBottom: '1.5rem' }}>The Chronos X1</h2>
    <p style={{ fontSize: '1.2rem', lineHeight: '1.8', marginBottom: '2rem' }}>
      Introducing the Chronos X1 – a perfect fusion of precision engineering and timeless design. 
      Crafted for those who demand excellence, the X1 blends cutting-edge materials with classic aesthetics to deliver a watch that's both bold and elegant.
    </p>

    <ul style={{ fontSize: '1.1rem', lineHeight: '1.8', listStyle: 'none', paddingLeft: 0 }}>
      <li>✔️ Sapphire Crystal Glass for scratch resistance</li>
      <li>✔️ Japanese Quartz Movement for accuracy</li>
      <li>✔️ 316L Stainless Steel Case, built to last</li>
      <li>✔️ Water Resistant up to 50 meters</li>
      <li>✔️ Sleek matte black dial with luminous markers</li>
      <li>✔️ Interchangeable genuine leather & silicone straps</li>
    </ul>

    <p style={{ marginTop: '2rem', fontStyle: 'italic', color: '#aaa' }}>
      Whether you're dressing up or down, the Chronos X1 complements every look.  
      Own the time. Own the moment.
    </p>
  </div>
</section>


       
      <section ref={contactRef} style={{ minHeight: '100vh', background: '#111', color: 'white', padding: '3rem' }}>
        <ContactForm />
      </section>
    </div>
  )
}

export default App
