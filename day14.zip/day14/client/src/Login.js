import { useState } from "react";
import { auth } from "./firebase";
import { signInWithEmailAndPassword } from "firebase/auth";
import { useNavigate    } from "react-router-dom";
import NavBar from "./NavBar";

export default function Login() {
  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");
  const nav = useNavigate();

  const login = async () => {
    try {
      await signInWithEmailAndPassword(auth, email, pass);
      alert("Signed In!");
      nav('/booklist')

    } catch (err) {
      alert(err.message);
    }
  };

  return (
    <>
    <NavBar/>
    <div className="p-4">
      <h2>Login</h2>
      <input type="email" placeholder="Email" onChange={e => setEmail(e.target.value)} />
      <br/><br/>
      <input placeholder="Password" type="password" onChange={e => setPass(e.target.value)} />
      <br/><br/>
      <button   onClick={login}>Login</button>
    </div>
    </>
  );
}

