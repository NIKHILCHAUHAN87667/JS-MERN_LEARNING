import {Link} from "react-router-dom";


function NavBar()
{
    return(
        <div className="nav">
        <Link to="/">Login</Link>
        <Link to="/signup">SignUp</Link>
        </div>
    );
}
export default NavBar;