function Succes()
{
    return(
        <div className="p-4">
        <h2>Payment Success ✅</h2>
        </div>
    );
}
export default Succes;