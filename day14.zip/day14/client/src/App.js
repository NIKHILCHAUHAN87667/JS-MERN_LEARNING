import { BrowserRouter , Routes , Route } from 'react-router-dom';
import './App.css';
import Login from './Login';
import Signup from './Signup';
import BookList from './BookList';
import Succes from './Succes';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path='/' element={<Login/>}/>
        <Route path='/signup' element={<Signup/>}/>      
        <Route path='/booklist' element={<BookList/>}/>
        <Route path="/success" element={<Succes/>} />
        <Route path="/cancel" element={<div>❌ Payment Cancelled</div>} />

        </Routes>
    </BrowserRouter>
  );
}

export default App;
