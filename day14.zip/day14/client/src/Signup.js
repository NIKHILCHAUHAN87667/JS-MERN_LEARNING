import { useState } from "react";
import { auth } from "./firebase";
import { createUserWithEmailAndPassword } from "firebase/auth";
import NavBar from "./NavBar";

export default function Signup() {
  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");

  const signup = async () => {
    try {
      await createUserWithEmailAndPassword(auth, email, pass);
      alert("Signed up!");
    } catch (err) {
      alert(err.message);
    }
  };

  return (
    <>
    <NavBar/>
    <div className="p-4">
      <h2>Signup</h2>
      <input type="email" placeholder="Email" onChange={e => setEmail(e.target.value)} />
      <br/>
      <br/>
      <input placeholder="Password" type="password" onChange={e => setPass(e.target.value)} />
      <br/>
      <br/>
      <button onClick={signup}>Signup</button>
    </div>
    </>
  );
}
