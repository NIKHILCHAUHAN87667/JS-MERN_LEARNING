import { useEffect, useState } from "react";
import { loadStripe } from "@stripe/stripe-js";

export default function BookList() {
  const [books, setBooks] = useState([]);
  const [query, setQuery] = useState("programming");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchBooks(query);
  }, []);

  const fetchBooks = async (searchTerm) => {
    setLoading(true);
    try {
      const res = await fetch(
        `https://www.googleapis.com/books/v1/volumes?q=${searchTerm}`
      );
      const data = await res.json();
      setBooks(data.items || []);
    } catch (err) {
      console.error("Error fetching books:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (e) => {
    e.preventDefault();
    fetchBooks(query);
  };

  const stripePromise = loadStripe("pk_test_51RduMMHKArgSojnxgs1sMmIqsC50gPuwMjglB5HxvPMDE7VR3F1TyzSKJFNlwhBD5vQh6L850fmCi9JWZ5PfwGWn00PfmOn25a");

async function handleCheckout(title, amount) {
  const res = await fetch("http://localhost:4242/create-checkout-session", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ title, amount }),
  });

  const data = await res.json();
  const stripe = await stripePromise;
  stripe.redirectToCheckout({ sessionId: data.sessionId });
}

  return (
    <div className="booklist-container">
      <form onSubmit={handleSearch} className="search-form">
        <input
          type="text"
          placeholder="Search for books..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="search-input"
        />
        <button type="submit" className="search-btn">
          Search
        </button>
      </form>

      {loading ? (
        <p>Loading books...</p>
      ) : (
        <div className="book-grid">
          {books.map((book) => (
            <div key={book.id} className="book-card">
              <h3 className="book-title">{book.volumeInfo.title}</h3>
              <img
                src={book.volumeInfo.imageLinks?.thumbnail}
                alt={book.volumeInfo.title}
                className="book-img"
              />
              <button
                onClick={() => handleCheckout(book.volumeInfo.title, 499)}
                className="buy-btn"
              >
                Buy ₹499
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );

}