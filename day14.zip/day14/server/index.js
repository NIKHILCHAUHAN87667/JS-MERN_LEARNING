const express = require("express");
const cors = require("cors");
const stripe = require("stripe")("sk_test_51RduMMHKArgSojnxzRwIlS90axI1MXNzCSdqw1Kw3mQcV9L0tbqumOhcE2QgjeB17FZDWjVygnQP30k8KxPq7vI100kHykh1L9"); // replace with your Stripe Secret Key

const app = express();
app.use(cors());
app.use(express.json());

app.post("/create-checkout-session", async (req, res) => {
  const session = await stripe.checkout.sessions.create({
    payment_method_types: ["card"],
    line_items: [
      {
        price_data: {
          currency: "inr",
          product_data: {
            name: req.body.title,
          },
          unit_amount: req.body.amount * 100,
        },
        quantity: 1,
      },
    ],
    mode: "payment",
    success_url: "http://localhost:3000/success",
    cancel_url: "http://localhost:5173/cancel",
  });

  res.json({ sessionId: session.id });

});

app.listen(4242, () => console.log("Server running on port 4242"));
