import React, { useRef, useState } from 'react'
import { Canvas, useFrame, useLoader } from '@react-three/fiber'
import { OrbitControls, Stars , Html} from '@react-three/drei'
import * as THREE from 'three'
import LandingPage from './Landing Page'
import EarthCube  from './EarthCube'
import MoonOrbit from './MoonOrbit'
import SpaceBackground from './SpaceBackGround'









export default function App() {
  return (
     <div style={{ position: 'absolute', top: 0, left: 0, width: '100vw', height: '100vh' }}>
     <LandingPage/>
          </div>
  )
}

