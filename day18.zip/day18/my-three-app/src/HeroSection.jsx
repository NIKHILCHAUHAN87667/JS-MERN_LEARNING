import { Canvas } from '@react-three/fiber'
import { OrbitControls } from '@react-three/drei'
import EarthCube  from './EarthCube'
import MoonOrbit from './MoonOrbit'
import SpaceBackground from './SpaceBackGround'

export default function HeroSection() {
  return (
    <div style={{ position: 'absolute', top: 0, left: 0, width: '100vw', height: '100vh' }}>
      <Canvas camera={{ position: [0, 0, 5] }}>
        <ambientLight intensity={0.5} />
        <pointLight position={[10, 10, 10]} />
        <SpaceBackground />
        <EarthCube />
        <MoonOrbit />
        <OrbitControls />
      </Canvas>

      {/* Overlay any text on top */}
      
    </div>
  )
}
