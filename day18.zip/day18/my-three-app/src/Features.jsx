function Features() {
  return (
    <section style={{textAlign:"center"}}>
      <h2>Why Choose Us</h2>
      <p>We're literally out of this world. 🌍🌕</p>
    </section>
  )
}
export default Features;