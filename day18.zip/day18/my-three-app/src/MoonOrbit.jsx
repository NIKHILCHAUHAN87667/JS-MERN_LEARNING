import React, { useRef, useState } from 'react'
import { Canvas, useFrame, useLoader } from '@react-three/fiber'
import { OrbitControls, Stars , Html} from '@react-three/drei'
import * as THREE from 'three'
 export default function MoonOrbit() {
  const pivotRef = useRef()
  const moonRef = useRef()
  const moonTexture = useLoader(THREE.TextureLoader, '/moon.jpg')
  const [moonlabel,setMoonLabel]= useState(false);


  useFrame((_, delta) => {
    pivotRef.current.rotation.y += delta * 0.1
    moonRef.current.rotation.y += delta * 1.0 
  })

  return (
    <group ref={pivotRef}>
      <mesh ref={moonRef} position={[3,0,0]} onPointerEnter={()=>setMoonLabel(!moonlabel)} onPointerLeave={()=>setMoonLabel(!moonlabel)}>  
        <sphereGeometry args={[0.5, 32, 32]} />
        <meshStandardMaterial map={moonTexture} />
        {moonlabel && (
    <Html center distanceFactor={10}>
      <div style={{
        background: 'rgba(0,0,0,0.7)',
        color: 'white',
        padding: '8px',
        borderRadius: '6px',
        fontSize: '14px',
        cursor:"pointer"
      }}>
        <strong>🌕 Moon</strong><br />
        Earth's only natural satellite.
      </div>
    </Html>
  )}
      </mesh>
    </group>
  )
}