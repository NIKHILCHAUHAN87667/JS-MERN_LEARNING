import React, { useRef, useState } from 'react'
import { Canvas, useFrame, useLoader } from '@react-three/fiber'
import { OrbitControls, Stars , Html} from '@react-three/drei'
import * as THREE from 'three'

 export default function EarthCube() {
  const meshRef = useRef()
  const earthTexture = useLoader(THREE.TextureLoader, '/earth.jpg')
  const [showlabel,setShowLabel] = useState(false);


  useFrame((_, delta) => {
    meshRef.current.rotation.y += delta * 0.5
  })

  return (
    <mesh ref={meshRef} onPointerEnter={()=>setShowLabel(!showlabel)} onPointerLeave={!showlabel}>
      <sphereGeometry args={[1.5, 64, 64]} />
      <meshStandardMaterial map={earthTexture} />
      {showlabel && (
        <Html center distanceFactor={10}>
          <div style={{
            background: 'rgba(0,0,0,0.7)',
            color: 'white',
            padding: '8px',
            borderRadius: '6px',
            fontSize: '14px',
            cursor:"pointer"
          }}>
            <strong>🌍 Earth</strong><br />
            Our home planet. Supports life!
          </div>
        </Html>
      )}
    </mesh>
  )
}