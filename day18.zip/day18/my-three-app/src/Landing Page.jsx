import HeroSection from "./heroSection"
import Features from "./Features"

export default function LandingPage() {
  return (
    <div>
        <div style={{
        position: 'absolute',
        top: '500',
        left: '10%',
        color: 'white',
        zIndex: 1,
        fontSize: '2rem',
        justifySelf:"center",
        textAlign:"center",
        marginLeft:"50px"
        
      }}>
        <h3>Explore the Universe</h3>
        <h3><p>Built with React + Three.js</p></h3>
      </div>
      <HeroSection />
      <br/><br/>
      <Features />
      
    </div>
  )
}
