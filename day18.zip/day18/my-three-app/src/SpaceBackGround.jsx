import React, { useRef, useState } from 'react'
import { Canvas, useFrame, useLoader } from '@react-three/fiber'
import { OrbitControls, Stars , Html} from '@react-three/drei'
import * as THREE from 'three'
export default function SpaceBackground() {
  const texture = useLoader(THREE.TextureLoader, '/space.jpg')
  return (
    <mesh>
      <sphereGeometry args={[100, 64, 64]} />
      <meshBasicMaterial map={texture} side={THREE.BackSide} />
    </mesh>
  )
}